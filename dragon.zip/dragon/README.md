# WELCOME TO Dragon Proxy
Dragonn Proxy is not static so u cant deploy it on vercel, github page cloudfare pages and etc.




**Dragon Proxy is available in these hosting sites**
# Deployments
- <a href="https://render.com" style="border-radius: 20px; display: inline-block; overflow: hidden;">
  <img border="0" alt="Render Deploy" src="https://imgtr.ee/images/2024/03/25/69f39403282546a97df46ebfb50e9c2a.th.png" width="100" height="100" style="border-radius: 10px;">
</a>

- <a href="https://app.fl0.com" style="border-radius: 20px; display: inline-block; overflow: hidden;">
  <img border="0" alt="fl0 Deploy" src="https://imgtr.ee/images/2024/03/25/7d594dd17c8802d4095c716d5b2ca810.jpeg" width="100" height="100" style="border-radius: 10px;">
</a>

- <a href="https://codesandbox.io" style="border-radius: 20px; display: inline-block; overflow: hidden;">
  <img border="0" alt="CodeSandbox Deploy" src="https://seeklogo.com/images/C/code-sandbox-logo-0746E97CA1-seeklogo.com.png" width="100" height="100" style="border-radius: 10px;">
</a>



**and any other website holders not static make sure u join the discord server for more.
discord server: https://discord.gg/nGb5nHyey4**

# Site Updates 24/7
**we know that the logo in the site is not working the devs are working on it.**
